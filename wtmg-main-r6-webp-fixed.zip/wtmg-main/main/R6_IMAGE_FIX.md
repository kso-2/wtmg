# v1.6.4 r6 image asset fix

This patch repairs the GitHub asset repository used by SionTRPGViewer v1.6.4.

- Converted 20 monster files whose names ended in `.webp` but whose bytes were PNG into actual WebP files.
- Kept the same asset IDs and paths, so `game/manifest.json` does not need path changes.
- Verified every manifest image against its extension and decoder format.
- Runtime r6 should use `https://image.sion91-images.net/assets/default/...` first and GitHub raw as fallback.
- Upload this repository patch before running the r6 APK environment setup so the local tunnel cache hydrates from the corrected files.

See `docs/WEBP_CONVERSION_REPORT.md` and `docs/webp_conversion_report.json` for the converted file list.
