# WebP conversion report

Converted files whose extension was `.webp` but whose bytes were PNG into real WebP files.

- Converted: **20** files
- Total before: **34,224,022 bytes**
- Total after: **3,771,810 bytes**
- Encoding: Pillow WebP quality 95, method 6

| File | Before | After |
|---|---:|---:|
| `assets/monsters/beasts/beast_01.webp` | 1,475,055 | 144,518 |
| `assets/monsters/beasts/beast_02.webp` | 1,659,260 | 162,618 |
| `assets/monsters/beasts/beast_03.webp` | 1,625,273 | 144,508 |
| `assets/monsters/beasts/beast_04.webp` | 1,646,402 | 171,834 |
| `assets/monsters/beasts/beast_05.webp` | 1,715,287 | 186,274 |
| `assets/monsters/hostile_races/hostile_race_01.webp` | 1,581,716 | 165,954 |
| `assets/monsters/hostile_races/hostile_race_02.webp` | 1,729,592 | 185,988 |
| `assets/monsters/hostile_races/hostile_race_03.webp` | 1,746,383 | 208,176 |
| `assets/monsters/hostile_races/hostile_race_04.webp` | 1,758,080 | 186,694 |
| `assets/monsters/hostile_races/hostile_race_05.webp` | 1,767,498 | 202,654 |
| `assets/monsters/military/military_01.webp` | 1,650,958 | 152,218 |
| `assets/monsters/military/military_02.webp` | 1,754,195 | 189,260 |
| `assets/monsters/military/military_03.webp` | 1,765,174 | 199,704 |
| `assets/monsters/military/military_04.webp` | 1,602,050 | 163,716 |
| `assets/monsters/military/military_05.webp` | 1,756,897 | 191,610 |
| `assets/monsters/robots/robot_01.webp` | 1,687,147 | 205,038 |
| `assets/monsters/robots/robot_02.webp` | 1,717,892 | 194,442 |
| `assets/monsters/robots/robot_03.webp` | 1,829,314 | 225,854 |
| `assets/monsters/robots/robot_04.webp` | 1,747,543 | 203,502 |
| `assets/monsters/robots/robot_05.webp` | 2,008,306 | 287,248 |
